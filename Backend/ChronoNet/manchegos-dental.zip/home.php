<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Si no está autenticado, redirigir al formulario de inicio de sesión
    header("Location: index.php");
    exit();
}

// Obtener el nombre de usuario de la sesión
$nombreUsuario = isset($_SESSION['usuario']) ? $_SESSION['usuario']['nombre'] : '';

include 'Conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="src/style_home.css">
    <title>Inicio</title>
    <link rel="icon" href="src/icon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="src/icon.ico" type="image/x-icon">
</head>

<body>

<div class="tabs">
    <!-- Asegúrate de que la etiqueta link para el logo esté antes de las pestañas -->
    <div class="logo">
        <svg xmlns="http://www.w3.org/2000/svg" width="500" height="158.53" viewBox="0 0 459.4 158.53"><g id="ebea1ccd-0308-41c9-adbf-b1c00759443d" data-name="Capa 2"><g id="ed749ee8-b5e6-49a7-8a72-ea1e462a41d3" data-name="Capa 1"><path d="M180,92.73a22.18,22.18,0,0,1,22.08-22.16,51.51,51.51,0,0,1,10.55.91V51.06c0-1.44,9.88-1.44,9.88,0v68.73c0,1.5-9.88,1.5-9.88,0v-.68a21.44,21.44,0,0,1-8.74,1.81h-1.81A22.12,22.12,0,0,1,180,98.84Zm32.63-10.17a22.9,22.9,0,0,0-8.74-2h-1.81a12.21,12.21,0,0,0-12.21,12.21v6.11A12.26,12.26,0,0,0,202.07,111h1.81a12.23,12.23,0,0,0,8.74-3.69Z" style="fill:#062a30"></path><path d="M257.77,120.92a22.26,22.26,0,0,1-22.08-22.08V92.73a22.06,22.06,0,0,1,22.08-22.08h.38a22.06,22.06,0,0,1,22.08,22.08v2.41c0,2.49-.53,5.2-2,5.2H245.64A12.44,12.44,0,0,0,257.77,111h1.88a12.53,12.53,0,0,0,10.48-6c1.36-2.34,9.87,2.56,8.52,5a22.27,22.27,0,0,1-19.07,10.93Zm0-40.4a12.22,12.22,0,0,0-12.13,10.86h24.64a12.24,12.24,0,0,0-12.13-10.86Z" style="fill:#062a30"></path><path d="M293.42,74.57c6.71-2.56,11.15-3.92,20.35-3.92a22.06,22.06,0,0,1,22.08,22.08v27.06c0,1.5-9.87,1.5-9.87,0V92.73a12.21,12.21,0,0,0-12.21-12.21H312a26.19,26.19,0,0,0-8.74,2v37.23c0,1.5-9.87,1.5-9.87,0Z" style="fill:#062a30"></path><path d="M354.39,79.77h-6.48c-1.5,0-1.5-9.12,0-9.12h6.48V57.24c0-1.44,9.88-1.44,9.88,0V70.65h9.19c1.51,0,1.51,9.12,0,9.12h-9.19v27.58c0,4,3.16,3.69,7.16,3.69h2c1.51,0,1.51,9.88,0,9.88h-2c-10.93,0-17-1.74-17-12.89Z" style="fill:#062a30"></path><path d="M416.8,119.11a22.74,22.74,0,0,1-8.75,1.81h-1.8A22.2,22.2,0,0,1,384,98.84V92.73a22.15,22.15,0,0,1,22.24-22.08c9.27,0,13.79,1.36,20.5,3.92v45.22c0,1.5-9.95,1.5-9.95,0Zm0-36.55a26.19,26.19,0,0,0-8.75-2h-1.8A12.27,12.27,0,0,0,394,92.73v6.11A12.27,12.27,0,0,0,406.25,111h1.8a12.25,12.25,0,0,0,8.75-3.69Z" style="fill:#062a30"></path><path d="M442.2,51c0-1.21,9.87-1.21,9.87,0v52.08c0,5,.53,6.18,1.05,6.85.76,1,3.55,1.06,4.15,1.06,2.64,0,2.86,10-.15,10-3.7-.08-9,.37-12-2.19-2-2.18-2.93-5-2.93-8.67Z" style="fill:#062a30"></path><path d="M180,14.43a24,24,0,0,1,11.08-2.31A8.85,8.85,0,0,1,196.85,14,23.45,23.45,0,0,1,207,12.12c6.61,0,10.1,5.82,10.1,13V41.05c0,.89-5.38.89-5.38,0V25.12c0-4-1.07-7.18-4.72-7.18h-1a12.56,12.56,0,0,0-4.76,1.19V41.05c0,.89-5.38.89-5.38,0V25.12c0-4-1.07-7.18-4.77-7.18h-.94a12.56,12.56,0,0,0-4.76,1.19V41.05c0,.89-5.38.89-5.38,0Z" style="fill:#10cfc9"></path><path d="M242.14,40.65a11.47,11.47,0,0,1-4.76,1.07h-1c-6.69,0-12.11-5.86-12.11-13v-3.6c0-7.18,5.42-13,12.11-13a24.79,24.79,0,0,1,11.17,2.31V41.05c0,.89-5.42.89-5.42,0Zm0-21.52a13.35,13.35,0,0,0-4.76-1.19h-1a7,7,0,0,0-6.69,7.18v3.6a7,7,0,0,0,6.69,7.19h1a6.43,6.43,0,0,0,4.76-2.18Z" style="fill:#10cfc9"></path><path d="M256,14.43a24.59,24.59,0,0,1,11.09-2.31c6.65,0,12,5.82,12,13V41.05c0,.89-5.38.89-5.38,0V25.12a6.94,6.94,0,0,0-6.65-7.18h-.95a13.35,13.35,0,0,0-4.76,1.19V41.05c0,.89-5.38.89-5.38,0Z" style="fill:#10cfc9"></path><path d="M298.31,41.72c-6.44,0-12-5.68-12-13V25.17c0-6.52,4.76-13,12-13.05h1a12,12,0,0,1,10.39,6.48c.74,1.38-3.9,4.31-4.64,2.89a6.66,6.66,0,0,0-5.71-3.55h-1c-4,0-6.65,3.64-6.65,7.23v3.55c0,4,3.08,7.19,6.61,7.19h1.07a6.65,6.65,0,0,0,5.71-3.51c.74-1.42,5.38,1.51,4.64,2.89a11.92,11.92,0,0,1-10.39,6.43Z" style="fill:#10cfc9"></path><path d="M317,.63c0-.84,5.38-.84,5.38,0V13.19a11.51,11.51,0,0,1,4.77-1.07H328c6.65,0,12,5.82,12,13V41.05c0,.89-5.38.89-5.38,0V25.12A6.93,6.93,0,0,0,328,17.94h-.94a6.38,6.38,0,0,0-4.77,2.17V41.05c0,.89-5.38.89-5.38,0Z" style="fill:#10cfc9"></path><path d="M359.29,41.72c-6.45,0-12-5.72-12-13v-3.6c0-7.18,5.38-13,12-13h.2c6.66,0,12,5.82,12,13v1.42c0,1.47-.29,3.07-1.11,3.07H352.68a7,7,0,0,0,6.61,6.3h1A6.75,6.75,0,0,0,366,32.36c.74-1.38,5.38,1.51,4.64,2.93a12,12,0,0,1-10.39,6.43Zm0-23.78a6.87,6.87,0,0,0-6.61,6.39h13.43a6.89,6.89,0,0,0-6.62-6.39Z" style="fill:#10cfc9"></path><path d="M387.78,53.88a9.85,9.85,0,0,1-1-.09,8.58,8.58,0,0,1-2.14-.58,6.63,6.63,0,0,1-2.05-1.51,8.82,8.82,0,0,1-1.6-2.44c-.66-1.42,4.19-4,4.84-2.57.21.44,1.65,2.26,2.63,2.26h3.25c2.13,0,3.94-2.79,3.94-5.1v-3.2a10.79,10.79,0,0,1-4.77,1.07h-.94c-6.65,0-12-5.81-12-13v-3.6c0-7.14,5.38-13,12-13A23.84,23.84,0,0,1,401,14.48V43.85c0,5.54-4.15,10-9.28,10Zm7.85-34.7a12.38,12.38,0,0,0-4.77-1.24h-.94a7,7,0,0,0-6.65,7.18v3.6a6.94,6.94,0,0,0,6.65,7.19h.94a6.39,6.39,0,0,0,4.77-2.18Z" style="fill:#10cfc9"></path><path d="M408.19,25.12c0-7.18,5.38-13,12-13h.95c6.65,0,12,5.82,12,13v3.6c0,7.19-5.38,13-12,13h-.95c-6.65,0-12-5.81-12-13Zm19.63,0a6.94,6.94,0,0,0-6.65-7.18h-.95a6.94,6.94,0,0,0-6.65,7.18v3.6a6.94,6.94,0,0,0,6.65,7.19h.95a6.94,6.94,0,0,0,6.65-7.19Z" style="fill:#10cfc9"></path><path d="M447.53,29.16l-.09,0a8.66,8.66,0,0,1-4.14-1.42A7.93,7.93,0,0,1,440,21a8.37,8.37,0,0,1,3.78-7.27A11.35,11.35,0,0,1,450,12.12a20.36,20.36,0,0,1,8.29,1.82c1.36.67-.82,6-2.17,5.37A15.43,15.43,0,0,0,450,17.94a7,7,0,0,0-3.41.84A2.38,2.38,0,0,0,445.43,21a1.81,1.81,0,0,0,.78,1.73,4.14,4.14,0,0,0,1.44.54h.17a20.63,20.63,0,0,1,6.32.88c2.91,1.07,5.26,3.64,5.26,8.39a8.66,8.66,0,0,1-6,8.52c-3.45,1.11-8.09.66-13.68-1-1.43-.45,0-6.08,1.48-5.64,5.22,1.6,8.67,1.64,10.6,1a2.76,2.76,0,0,0,2.17-3,3.17,3.17,0,0,0-.45-2,2.18,2.18,0,0,0-1.15-.85,9.89,9.89,0,0,0-2.3-.44c-.49,0-.94,0-1.35-.09Z" style="fill:#10cfc9"></path><path d="M180.92,158.53c-.42,0-.79-.07-.79-.21V146.66c0-.27,1.7-.27,1.7,0v10.17h5.43c.25,0,.25,1.7,0,1.7Z" style="fill:#10cfc9"></path><path d="M194.14,146.67c.06-.15.48-.21,1-.21s.93.06,1,.21L200,158.32c0,.28-1.66.27-1.79,0L197,154.77h-3.77l-1.17,3.55c-.13.27-1.8.28-1.8,0Zm-.33,6.42h2.68L195.15,149Z" style="fill:#10cfc9"></path><path d="M203.74,158.53c-.52,0-.75-.08-.75-.15V146.62c0-.12.51-.17,1-.16h2.71a3.51,3.51,0,0,1,3.49,3.53,3,3,0,0,1-.8,2.09,3.53,3.53,0,0,1,1.52,2.92,3.49,3.49,0,0,1-3.46,3.53Zm.95-10.26v3.21h2.16a1.56,1.56,0,0,0,1.61-1.49,1.78,1.78,0,0,0-1.8-1.72Zm0,4.87v3.58h2.72a1.75,1.75,0,0,0,1.77-1.72,1.89,1.89,0,0,0-1.61-1.86Z" style="fill:#10cfc9"></path><path d="M214.12,151.72a5.07,5.07,0,0,1,4.86-5.26h.32a5.07,5.07,0,0,1,4.88,5.26v1.54a5.08,5.08,0,0,1-4.88,5.27H219a5.08,5.08,0,0,1-4.86-5.27Zm8.36,0a3.31,3.31,0,0,0-3.18-3.43H219a3.31,3.31,0,0,0-3.16,3.43v1.54a3.3,3.3,0,0,0,3.16,3.43h.32a3.31,3.31,0,0,0,3.18-3.43Z" style="fill:#10cfc9"></path><path d="M231.42,154.41a.56.56,0,0,0-.5-.37h-1.79v4.32c0,.21-1.71.21-1.71,0V146.62c0-.09.36-.16.82-.17h3.83a3.82,3.82,0,0,1,3.49,3.85,3.75,3.75,0,0,1-2.37,3.59l2.37,4.44c0,.27-1.89.26-2,0Zm-2.29-6.14v4.11h2.94c1,0,1.8-1.2,1.8-2.08a2.07,2.07,0,0,0-1.8-2Z" style="fill:#10cfc9"></path><path d="M242.26,146.67c.06-.15.48-.21,1-.21s.94.06,1,.21l3.82,11.65c0,.28-1.66.27-1.79,0l-1.17-3.55h-3.77l-1.18,3.55c-.13.27-1.79.28-1.79,0Zm-.33,6.42h2.68L243.27,149Z" style="fill:#10cfc9"></path><path d="M252.56,148.29h-3.39a3,3,0,0,1,0-1.83h8.48a3,3,0,0,1,0,1.83h-3.4v10.09c0,.21-1.69.21-1.69,0Z" style="fill:#10cfc9"></path><path d="M260.13,151.72a5.07,5.07,0,0,1,4.86-5.26h.33a5.07,5.07,0,0,1,4.87,5.26v1.54a5.08,5.08,0,0,1-4.87,5.27H265a5.08,5.08,0,0,1-4.86-5.27Zm8.36,0a3.31,3.31,0,0,0-3.17-3.43H265a3.31,3.31,0,0,0-3.16,3.43v1.54a3.3,3.3,0,0,0,3.16,3.43h.33a3.3,3.3,0,0,0,3.17-3.43Z" style="fill:#10cfc9"></path><path d="M277.43,154.41a.56.56,0,0,0-.5-.37h-1.79v4.32c0,.21-1.7.21-1.7,0V146.62c0-.09.35-.16.82-.17h3.82a3.83,3.83,0,0,1,3.5,3.85,3.76,3.76,0,0,1-2.38,3.59l2.38,4.44c0,.27-1.9.26-2,0Zm-2.29-6.14v4.11h2.94c1,0,1.81-1.2,1.81-2.08a2.07,2.07,0,0,0-1.81-2Z" style="fill:#10cfc9"></path><path d="M284.82,146.62c0-.21,1.71-.21,1.71,0v11.76c0,.21-1.71.21-1.71,0Z" style="fill:#10cfc9"></path><path d="M289.77,151.72a5.08,5.08,0,0,1,4.87-5.26H295a5.08,5.08,0,0,1,4.88,5.26v1.54a5.09,5.09,0,0,1-4.88,5.27h-.32a5.09,5.09,0,0,1-4.87-5.27Zm8.37,0a3.31,3.31,0,0,0-3.18-3.43h-.32a3.31,3.31,0,0,0-3.16,3.43v1.54a3.3,3.3,0,0,0,3.16,3.43H295a3.31,3.31,0,0,0,3.18-3.43Z" style="fill:#10cfc9"></path><path d="M139.07,74.25l.18-22.74a38.29,38.29,0,0,0-11.72-28.6,40.45,40.45,0,0,0-52.27-4.1,39.06,39.06,0,0,0-23.63-7.69A39.37,39.37,0,0,0,23,22.91,38.9,38.9,0,0,0,11.1,51.48V74.25H0V51.48C0,37.19,4.94,25.3,15.11,15.13S37.16,0,51.45,0A51.42,51.42,0,0,1,73,5l2,1,2.06-1A51.34,51.34,0,0,1,98.71,0C113,0,124.93,5,135.16,15.14s15.18,22,15.18,36.34V74.25Z" style="fill:#10cfc9"></path><path d="M122.53,120.86a25.72,25.72,0,0,1-20-8.76L99,108.24,95.36,112c-5.75,6-12.33,8.86-20.1,8.86A26.43,26.43,0,0,1,55.19,112l-3.53-3.72L48.1,112A26.71,26.71,0,0,1,28,120.68a26.82,26.82,0,0,1-19.73-8.21A26.3,26.3,0,0,1,.08,95H11.23a16.44,16.44,0,0,0,4.71,9.79,16,16,0,0,0,11.88,5,16.37,16.37,0,0,0,11.92-5,16.37,16.37,0,0,0,5-11.92V69.23a6.89,6.89,0,0,1,6.73-6.72,6.89,6.89,0,0,1,6.73,6.72V92.87a16.2,16.2,0,0,0,5,12A16.85,16.85,0,0,0,87,104.79a16.33,16.33,0,0,0,5-11.92V69.23a6.27,6.27,0,0,1,2-4.71,6.73,6.73,0,0,1,11.44,4.71V92.87a16.2,16.2,0,0,0,5,12,16.47,16.47,0,0,0,11.87,4.85A16.64,16.64,0,0,0,138.94,95h11.33a28,28,0,0,1-27.74,25.91Z" style="fill:#10cfc9"></path><rect x="0.08" y="146.74" width="150.27" height="11.79" style="fill:#10cfc9"></rect></g></g></svg>
        </svg>
    </div>

    <div class="tab" onclick="openTab('Usuarios')">Usuarios</div>
    <div class="tab" onclick="openTab('Registros')">Registros</div>
    <div class="tab" onclick="openTab('Partes')">Partes</div>
    <div class="tab"><p class="usuario-nombre"><?php echo "<b>Usuario Activo: </b>" . $_SESSION['usuario']['nombre']; ?></p></div>
    <div class="tab" style="cursor: pointer; color: red;" onclick="cerrarSesion()">Cerrar Sesión</div>
</div>

<div id="Usuarios" class="tab-content">
    <h2 class="posicionamiento-textos">Usuarios:</h2>
    <p class="posicionamiento-textos">Desde este apartado puedes visualizar los usuarios en formato tabla, también puedes editarlos o crear nuevos usuarios.</p>

    <?php

    $usuariosPorPagina = 10;

    // Obtener el número de página actual para usuarios
    $paginaUsuarios = isset($_GET['pagina_usuarios']) ? $_GET['pagina_usuarios'] : 1;

    // Calcular el offset para la paginación de usuarios
    $offsetUsuarios = ($paginaUsuarios - 1) * $usuariosPorPagina;

    // Realizar la consulta de usuarios con LIMIT para la paginación
    $queryUsuarios = "SELECT * FROM TUsuarios ORDER BY IdUsuario ASC OFFSET $offsetUsuarios ROWS FETCH NEXT $usuariosPorPagina ROWS ONLY";
    $resultUsuarios = sqlsrv_query($conn, $queryUsuarios);

    if ($resultUsuarios === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Crear la tabla HTML de usuarios
    echo '<table class="tablas-listado" border="1">';
    echo '<tr id="header-row"><th class="my-cell">ID</th><th class="my-cell">Usuario</th><th class="my-cell">Codigo</th><th class="my-cell">Nombre</th><th class="my-cell">Apellidos</th><th class="my-cell">Administrador</th><th class="my-cell"></th><th class="my-cell"></th></tr>';

    // Recorrer los resultados de usuarios y agregar cada fila a la tabla
    while ($rowUsuarios = sqlsrv_fetch_array($resultUsuarios, SQLSRV_FETCH_ASSOC)) {
        $adminBool = ($rowUsuarios['AdminBool'] == "1") ? "SI" : "NO";
    
        echo '<tr>';
        echo '<td class="td-list">' . $rowUsuarios['IdUsuario'] . '</td>';
        echo '<td class="td-list">' . $rowUsuarios['Login'] . '</td>';
        echo '<td class="td-list">' . $rowUsuarios['Codigo'] . '</td>';
        echo '<td class="td-list">' . $rowUsuarios['Nombre'] . '</td>';
        echo '<td class="td-list">' . $rowUsuarios['Apellidos'] . '</td>';
        echo '<td class="td-list">' . $adminBool . '</td>';
        echo '<td class="td-list"><a href="editar_usuario.php?id=' . $rowUsuarios['IdUsuario'] . '"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#3498db" d="M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z"/></svg></a></td>';
        echo '<td class="td-list"><a onclick="return confirmarEliminar(' . $rowUsuarios['IdUsuario'] . ')" href="">';
        echo '<img style="width:20px;margin-left:50%; transform:translateX(-50%);" src="src/eliminar.png"></a></td>';
        echo '</tr>';
    }

    echo '</table>';

    // Calcular el número total de usuarios para la paginación
    $queryTotalUsuarios = "SELECT COUNT(*) AS totalUsuarios FROM TUsuarios";
    $resultTotalUsuarios = sqlsrv_query($conn, $queryTotalUsuarios);
    $totalUsuarios = sqlsrv_fetch_array($resultTotalUsuarios)['totalUsuarios'];

    // Calcular el número total de páginas para usuarios
    $totalPaginasUsuarios = ceil($totalUsuarios / $usuariosPorPagina);

    // Mostrar los enlaces de paginación para usuarios
    echo '<div class="paginacion">';
    for ($i = 1; $i <= $totalPaginasUsuarios; $i++) {
        if ($i == $paginaUsuarios) {
            echo '<span class="current">' . $i . '</span> ';
        } else {
            echo '<a href="?pagina_usuarios=' . $i . '">' . $i . '</a> ';
        }
    }
    echo '</div>';

    // Liberar los recursos de usuarios
    sqlsrv_free_stmt($resultUsuarios);
    sqlsrv_free_stmt($resultTotalUsuarios);
    ?>

    <!-- Botón para abrir el formulario popup -->
    <button id="crearUsuarioBtn" class="crear-usuario-button" onclick="mostrarFormulario()">Crear Nuevo Usuario</button>

    <script>
        function confirmarEliminar(idUsuario) {
            
                window.location.href = 'eliminar_usuario.php?id=' + idUsuario;
            
            return false; // Para prevenir el comportamiento predeterminado del enlace
        }
    </script>

    <!-- Formulario popup -->
    <div id="formularioPopup" class="popup-form">
        <form id="nuevoUsuarioForm" action="procesar_formulario.php" method="post">
            <label for="nuevoUsuario">Usuario:</label>
            <input type="text" name="nuevoUsuario" required>
            <br><br>
            <label for="nuevoCodigo">Codigo:</label>
            <input type="text" name="nuevoCodigo" required>
            <br><br>
            <label for="nuevoNombre">Nombre:</label>
            <input type="text" name="nuevoNombre" required>
            <br><br>
            <label for="nuevoApellidos">Apellidos:</label>
            <input type="text" name="nuevoApellidos" required>
            <br><br>
            <label for="nuevoAdministrador">Administrador:</label>
            <input type="checkbox" name="nuevoAdministrador">
            <br><br>
            <button type="submit" name="submitForm">Guardar</button>
            <button type="button" onclick="cerrarFormulario()">Cancelar</button>
        </form>
    </div>
</div>

<div id="Registros" class="tab-content">
    <h2 class="posicionamiento-textos">Registros</h2>
    <p class="posicionamiento-textos">Listado de registros que permite filtrar y descargarlos en formato xlsx.</p>

    <?php

$queryHorasTrabajadas = "SELECT r.IdRegistro, r.IdUsuario, CONCAT(u.Nombre, ' ', u.Apellidos) AS nombrecompleto, r.Tipo, r.FechaHora, r.Incidencia 
FROM TRegistro r 
JOIN TUsuarios u ON u.IdUsuario = r.IdUsuario";

$resultHoras = sqlsrv_query($conn, $queryHorasTrabajadas);

if ($resultHoras === false) {
    die(print_r(sqlsrv_errors(), true));
}

$horasPausa = 0;
$minutosPausa = 0;

echo '<script>';
echo 'document.addEventListener("DOMContentLoaded", function() {';
while ($row = sqlsrv_fetch_array($resultHoras, SQLSRV_FETCH_ASSOC)) {
    // Utilizar el ID del usuario como el valor del option
    $idRegistroHoras = $row['IdRegistro'];
    $idUsuarioHoras = $row['IdUsuario'];
    $tipo = $row['Tipo'];
    $fechaHoraSalida = $row['FechaHora'];

    if ($tipo == 1) {
        // Obtener la fecha de la salida actual
        $fechaSalida = $fechaHoraSalida->format('Y-m-d H:i:s.u');
        $fechaEntradaFunc = obtenerHoraEntrada($idUsuarioHoras, $fechaSalida, $conn);
        $fechaPausaFunc = obtenerHoraPausa($idUsuarioHoras, $fechaSalida, $conn);
        $fechaReanudaFunc = obtenerHoraReanudar($idUsuarioHoras, $fechaSalida, $conn);

                // Extraer solo las horas de la fecha y hora de entrada
                $horaEntrada = substr($fechaEntradaFunc, 11, 8);
                $horaPausa = substr($fechaPausaFunc, 11, 8);
                $horaReanuda = substr($fechaReanudaFunc, 11, 8); // Extraer desde el índice 11, longitud de 8 caracteres
                $horaSalida = substr($fechaSalida, 11, 8);

                // Obtener la fecha y hora formateada
                $horaEntradaDt = formatearStringHoras($horaEntrada);
                $horaSalidaDt = formatearStringHoras($horaSalida);
                $horaPausaDt = formatearStringHoras($horaPausa);
                $horaReanudaDt = formatearStringHoras($horaReanuda);

                // Verificar si ambas fechas están en el formato correcto
                if ($horaEntradaDt !== false && $horaSalidaDt !== false) {
                    // Crear objetos DateTime para las fechas de entrada y salida
                    $fechaHoraEntrada_dt = new DateTime($fechaEntradaFunc);
                    $fechaHoraSalida_dt = new DateTime($fechaSalida);

                    // Calcular la diferencia entre las fechas de entrada y salida
                    $diferencia = $fechaHoraSalida_dt->diff($fechaHoraEntrada_dt);

                    // Obtener la diferencia en horas y minutos
                    $horasJornada = $diferencia->format('%h');
                    $minutosJornada = $diferencia->format('%i');

                }

                // Verificar si ambas fechas están en el formato correcto
                if ($horaPausaDt !== false && $horaReanudaDt !== false) {
                    // Crear objetos DateTime para las fechas de pausa y reanudación
                    $fechaPausaFunc_dt = new DateTime($fechaPausaFunc);
                    $fechaReanudaFunc_dt = new DateTime($fechaReanudaFunc);

                    // Calcular la diferencia entre las fechas de pausa y reanudación
                    $diferenciaPausa = $fechaReanudaFunc_dt->diff($fechaPausaFunc_dt);

                    // Obtener la diferencia en horas y minutos
                    $horasPausa = $diferenciaPausa->format('%h');
                    $minutosPausa = $diferenciaPausa->format('%i');

                }

                // Restar las horas y minutos de la diferencia de pausa de la diferencia de jornada
                $totalHoras = $horasJornada - $horasPausa;
                $totalMinutos = $minutosJornada - $minutosPausa;

                // Ajustar los minutos si son negativos
                if ($totalMinutos < 0) {
                    $totalHoras--;
                    $totalMinutos += 60;
                }

                // Formatear los valores de horas y minutos con dos dígitos
                $totalHorasFormateadas = sprintf('%02d', $totalHoras);
                $totalMinutosFormateados = sprintf('%02d', $totalMinutos);

                // Aquí asignas el valor de horas trabajadas a la celda correspondiente por su ID de registro
                echo "var horasTrab = '$totalHorasFormateadas:$totalMinutosFormateados';";
                echo "var cell = document.getElementById('$idRegistroHoras');";
                echo "if (cell) {";
                echo "    cell.textContent = horasTrab;";
                echo "}";

                // Crea un array asociativo para almacenar la información del registro actual
                $registro = array(
                    'idRegistro' => $idRegistroHoras,
                    'horas' => $totalHoras,
                    'minutos' => $totalMinutos
                );

                // Agrega el array del registro al array principal
                $registros[] = $registro;
        }
}

$registros_json = json_encode($registros);

echo '});';
echo '</script>';

    // Definir el filtro de fecha y hora si se ha enviado en el formulario
    $filtroFechaHora = isset($_POST['filtroFechaHora']) ? $_POST['filtroFechaHora'] : '';
    $filtroFechaHoraFinal = isset($_POST['filtroFechaHoraFinal']) ? $_POST['filtroFechaHoraFinal'] : '';
    $filtroNombreCompleto = isset($_POST['filtroNombreCompleto']) ? $_POST['filtroNombreCompleto'] : '';

// Consulta SQL con el filtro de fecha y hora
$query = "SELECT r.IdRegistro, r.IdUsuario, CONCAT(u.Nombre, ' ', u.Apellidos) AS nombrecompleto, r.Tipo, r.FechaHora, r.Incidencia 
          FROM TRegistro r 
          JOIN TUsuarios u ON u.IdUsuario = r.IdUsuario";

// Agregar el filtro de fecha y hora si se ha proporcionado
if (!empty($filtroFechaHora)) {
    // Ajustar el formato de fecha y hora para que coincida con el de la base de datos
    $filtroFechaHora = date('Y-m-d H:i:s', strtotime($filtroFechaHora));
    $query .= " WHERE CONVERT(varchar, r.FechaHora, 120) LIKE '%$filtroFechaHora%'";
}

if (!empty($filtroNombreCompleto)) {
    // Agregar el filtro de nombre completo si se ha proporcionado
    $query .= " AND CONCAT(u.Nombre, ' ', u.Apellidos) LIKE '%$filtroNombreCompleto%'";
}

// Ordenar por usuario y fecha/hora
$query .= " ORDER BY r.FechaHora DESC";


    $result = sqlsrv_query($conn, $query);

    if ($result === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    echo '<meta charset="UTF-8"><br><br>';
    echo '<form id="filtroForm" method="post" action="descargar_registros.php">';
    echo '<div id="filtros" style="display: flex; flex-wrap: wrap; justify-content: space-between;">';

    // Agregar los campos de búsqueda para cada columna
    echo '<div style="flex: 0 0 30%;">';
    echo '    <label for="filtroNombreCompleto">Nombre Completo:</label>';
    echo '    <select id="filtroNombreCompleto" name="filtroNombreCompleto" class="filtroCampo">';
    echo '        <option value="">Selecciona un nombre...</option>';

    // Realizar la consulta para obtener los nombres completos de los usuarios con su ID
    $queryUsuarios = "SELECT IdUsuario, CONCAT(Nombre, ' ', Apellidos) AS NombreCompleto FROM TUsuarios";
    $resultUsuarios = sqlsrv_query($conn, $queryUsuarios);

    if ($resultUsuarios === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Iterar sobre los resultados y mostrar cada nombre completo como una opción en el select
    while ($row = sqlsrv_fetch_array($resultUsuarios, SQLSRV_FETCH_ASSOC)) {
        // Utilizar el ID del usuario como el valor del option
        echo '<option value="' . $row['NombreCompleto'] . '">' . $row['NombreCompleto'] . '</option>';
    }

    // Liberar los recursos de la consulta
    sqlsrv_free_stmt($resultUsuarios);

    echo '    </select>';
    echo '</div>';
    echo '<div style="flex: 0 0 30%;"><label for="filtroTipo">Tipo:</label> <input type="text" id="filtroTipo" class="filtroCampo" name="filtroTipo" value=""></div>';
    echo '<div style="flex: 0 0 30%;"><label for="filtroIncidencia">Incidencia:</label> <input type="text" id="filtroIncidencia" class="filtroCampo" name="filtroIncidencia" value=""></div>';
    echo '<div style="flex: 0 0 30%;"><label for="filtroFechaHora">Fecha Inicial:</label>';
    echo '<input type="date" id="filtroFechaHora" class="filtroCampo" name="filtroFechaHora" value=""></div>';
    echo '<input type="hidden" name="registros" value="<?php echo htmlspecialchars($registros_json); ?>">';
    
    echo '<div style="flex: 0 0 30%;"><label for="filtroFechaHoraFinal">Fecha Final:</label>';
    echo '<input type="date" id="filtroFechaHoraFinal" class="filtroCampo" name="filtroFechaHoraFinal" value=""></div>';

    echo '<div style="flex: 0 0 30%;"><button type="submit" name="descargar" class="descargar-btn">Descargar Registros</button><button style="margin-left:20px;" type="reset" onclick="resetFiltros()" class="reset-btn">Reset</button></div>';

    echo '</div>';
    echo '</form>';
    echo '<button id="crearRegistroBtn" class="crear-usuario-button" onclick="mostrarFormularioRegistro()">Nuevo Registro</button>';
    echo '<table class="tablas-listado" border="1">';
    echo '<tr id="header-row"><th class="my-cell">ID Registro</th><th class="my-cell">Nombre</th><th class="my-cell">Tipo</th><th class="my-cell">Fecha y Hora</th><th class="my-cell">Incidencia</th><th class="my-cell" id="horas-trab">Horas</th><th class="my-cell"></th></tr>';

// Recorrer los resultados y agregar cada fila a la tabla
while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
    echo '<tr>';
    echo '<td class="td-list">' . $row['IdRegistro'] . '</td>';
    echo '<td class="td-list" value="' . $row['IdUsuario'] . '">' . $row['nombrecompleto']  . '</td>';

    $tipo = $row['Tipo'];
    $tipoTexto = '';
    switch ($tipo) {
        case 0:
            $tipoTexto = 'Entrada';
            break;
        case 1:
            $tipoTexto = 'Salida';
            break;
        case 2:
            $tipoTexto = 'Pausa';
            break;
        case 3:
            $tipoTexto = 'Reanudar';
            break;
    }

    echo '<td class="td-list">' . $tipoTexto . '</td>';
    echo '<td class="td-list">' . $row['FechaHora']->format('Y-m-d H:i:s') . '</td>';
    echo '<td class="td-list">' . $row['Incidencia'] . '</td>';
    echo '<td class="td-list" id="' . $row['IdRegistro'] . '"> </td>';
    echo '<td class="td-list"><a href="eliminar_registro.php?id=' . $row['IdRegistro'] . '">';
    echo '<img style="width:20px;margin-left:50%; transform:translateX(-50%);" src="src/eliminar.png"></a></td>';
    echo '</tr>';
}

echo '</table>';

    

    function formatearStringHoras($hora) {
        // Separar la cadena de hora en sus componentes (horas, minutos, segundos)
        $componentesHora = explode(':', $hora);
    
        // Verificar si se obtuvieron los componentes correctamente
        if (count($componentesHora) === 3) {
            // Crear un objeto DateTime con los componentes
            $hora_dt = new DateTime();
            $hora_dt->setTime($componentesHora[0], $componentesHora[1], $componentesHora[2]);
    
            // Verificar si se creó correctamente el objeto DateTime
            if ($hora_dt !== false) {
                // Obtener la hora formateada en "hh:mm:ss"
                $horaFormateada = $hora_dt->format('H:i:s');
                return $horaFormateada;
            } else {
                // Manejar el caso en que la conversión falle
                return false;
            }
        } else {
            // Manejar el caso en que la cadena de hora no tenga el formato esperado
            return false;
        }
    }
    function obtenerHoraEntrada($idUsuarioHoras, $fechaSalida, $conn){
        // Inicializar la variable $fechaHoraEntrada
        $fechaHoraEntrada = null;
    
        // Consulta para obtener la última entrada del usuario en el mismo día que la salida actual
        $query = "SELECT TOP 1 FechaHora, IdUsuario
                  FROM TRegistro 
                  WHERE IdUsuario = $idUsuarioHoras 
                  AND Tipo = 0 
                  AND CONVERT(date, FechaHora) = '$fechaSalida'
                  ORDER BY FechaHora DESC";
    
        // Ejecutar la consulta
        $result = sqlsrv_query($conn, $query);
    
        if ($result === false) {
            die(print_r(sqlsrv_errors(), true));
        }
    
        // Verificar si hay resultados
        if (sqlsrv_has_rows($result)) {
            // Obtener la hora de entrada
            $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
            $fechaHoraEntrada = $row['FechaHora']->format('Y-m-d H:i:s.u');
        }
    
        return $fechaHoraEntrada;
    }
    function obtenerHoraPausa($idUsuarioHoras, $fechaSalida, $conn){
        // Inicializar la variable $fechaHoraEntrada
        $fechaHoraPausa = null;
    
        // Consulta para obtener la última entrada del usuario en el mismo día que la salida actual
        $query = "SELECT TOP 1 FechaHora, IdUsuario
                  FROM TRegistro 
                  WHERE IdUsuario = $idUsuarioHoras 
                  AND Tipo = 2 
                  AND CONVERT(date, FechaHora) = '$fechaSalida'
                  ORDER BY FechaHora DESC";
    
        // Ejecutar la consulta
        $result = sqlsrv_query($conn, $query);
    
        if ($result === false) {
            die(print_r(sqlsrv_errors(), true));
        }
    
        // Verificar si hay resultados
        if (sqlsrv_has_rows($result)) {
            // Obtener la hora de entrada
            $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
            $fechaHoraPausa = $row['FechaHora']->format('Y-m-d H:i:s.u');
        }
    
        return $fechaHoraPausa;
    }
    function obtenerHoraReanudar($idUsuarioHoras, $fechaSalida, $conn){
        // Inicializar la variable $fechaHoraEntrada
        $fechaHoraReanuda = null;
    
        // Consulta para obtener la última entrada del usuario en el mismo día que la salida actual
        $query = "SELECT TOP 1 FechaHora, IdUsuario
                  FROM TRegistro 
                  WHERE IdUsuario = $idUsuarioHoras 
                  AND Tipo = 3 
                  AND CONVERT(date, FechaHora) = '$fechaSalida'
                  ORDER BY FechaHora DESC";
    
        // Ejecutar la consulta
        $result = sqlsrv_query($conn, $query);
    
        if ($result === false) {
            die(print_r(sqlsrv_errors(), true));
        }
    
        // Verificar si hay resultados
        if (sqlsrv_has_rows($result)) {
            // Obtener la hora de entrada
            $row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC);
            $fechaHoraReanuda = $row['FechaHora']->format('Y-m-d H:i:s.u');
        }
    
        return $fechaHoraReanuda;
    }
    



// Agregar el filtro de fecha y hora si se ha proporcionado
if (!empty($filtroFechaHora)) {
// Ajustar el formato de fecha y hora para que coincida con el de la base de datos
$filtroFechaHora = date('Y-m-d H:i:s', strtotime($filtroFechaHora));
$query .= " WHERE CONVERT(varchar, r.FechaHora, 120) LIKE '%$filtroFechaHora%'";
}

if (!empty($filtroNombreCompleto)) {
// Agregar el filtro de nombre completo si se ha proporcionado
$query .= " AND CONCAT(u.Nombre, ' ', u.Apellidos) LIKE '%$filtroNombreCompleto%'";
}

// Ordenar por usuario y fecha/hora
$query .= " ORDER BY r.IdUsuario, r.FechaHora";

    // Liberar los recursos
    sqlsrv_free_stmt($result);

    ?>

    <!-- Formulario popup Registro-->
    <div id="formularioPopupRegistro" class="popup-form">
    <form id="nuevoUsuarioForm" action="procesar_formulario_registro.php" method="post">
        <label for="usuarios">Selecciona un usuario:</label>
        <select id="usuarios" name="usuarios" class="select-partes">
            <?php
            // Realizar la consulta para obtener los nombres completos de los usuarios con su ID
            $queryUsuarios = "SELECT IdUsuario, CONCAT(Nombre, ' ', Apellidos) AS NombreCompleto FROM TUsuarios";
            $resultUsuarios = sqlsrv_query($conn, $queryUsuarios);

            if ($resultUsuarios === false) {
                die(print_r(sqlsrv_errors(), true));
            }

            // Iterar sobre los resultados y mostrar cada nombre completo como una opción en el select
            while ($row = sqlsrv_fetch_array($resultUsuarios, SQLSRV_FETCH_ASSOC)) {
                // Utilizar el ID del usuario como el valor del option
                echo '<option value="' . $row['IdUsuario'] . '">' . $row['NombreCompleto'] . '</option>';
            }

            // Liberar los recursos de la consulta
            sqlsrv_free_stmt($resultUsuarios);
            ?>
        </select>
        <br><br>
        <label for="fechaHora">Fecha y Hora:</label>
        <input type="datetime-local" id="fechaHora" name="fechaHora" class="select-partes">
        <br><br>
        <label for="incidencia">Incidencia:</label>
        <select id="incidencia" name="incidencia" class="select-partes">
            <option value="SI">SI</option>
            <option value="NO">NO</option>
        </select>
        <br><br>
        <label for="tipo">Tipo:</label>
        <select id="tipo" name="tipo" class="select-partes">
            <option value="0">Entrada</option>
            <option value="2">Pausa</option>
            <option value="3">Reanudar</option>
            <option value="1">Salida</option>
        </select>
        <br><br>
        <button type="submit" name="submitForm">Guardar</button>
        <button type="button" onclick="cerrarFormularioRegistro()">Cancelar</button>
    </form>
</div>
</div>


<div id="Partes" class="tab-content">
    <h2 class="posicionamiento-textos">Partes</h2>
    <p class="posicionamiento-textos">Listado de registros que permite filtrar y descargarlos en formato xlsx.</p>

    <form style="margin-left: 5%; margin-top: 40px;" method="post" action="procesar_partes.php">
    <div style="flex: 0 0 30%;">
        <label for="usuarios">Selecciona un usuario:</label>
        <select id="usuarios" name="usuarios" class="select-partes">
            <?php
            // Realizar la consulta para obtener los nombres completos de los usuarios con su ID
            $queryUsuarios = "SELECT IdUsuario, CONCAT(Nombre, ' ', Apellidos) AS NombreCompleto FROM TUsuarios";
            $resultUsuarios = sqlsrv_query($conn, $queryUsuarios);

            if ($resultUsuarios === false) {
                die(print_r(sqlsrv_errors(), true));
            }

            // Iterar sobre los resultados y mostrar cada nombre completo como una opción en el select
            while ($row = sqlsrv_fetch_array($resultUsuarios, SQLSRV_FETCH_ASSOC)) {
                // Utilizar el ID del usuario como el valor del option
                echo '<option value="' . $row['IdUsuario'] . '">' . $row['NombreCompleto'] . '</option>';
            }

            // Liberar los recursos de la consulta
            sqlsrv_free_stmt($resultUsuarios);
            ?>
        </select>
    </div>

    <div style="flex: 0 0 30%;">
        <label for="meses">Selecciona un mes:</label>
        <select id="meses" name="meses" class="select-partes">
            <?php
            // Generar opciones para los meses del año
            $meses = array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
            foreach ($meses as $mes) {
                echo '<option value="' . $mes . '">' . $mes . '</option>';
            }
            ?>
        </select>
    </div>

    <div style="flex: 0 0 30%;">
        <label for="anios">Selecciona un año:</label>
        <select id="anios" name="anios" class="select-partes">
            <?php
            // Generar opciones para los años
            $anioInicial = 2020; // Año inicial
            $anioFinal = date("Y") + 5; // Año final (5 años en el futuro)
            for ($anio = $anioInicial; $anio <= $anioFinal; $anio++) {
                $selected = ($anio == date("Y")) ? "selected" : ""; // Verificar si el año es el actual
                echo '<option value="' . $anio . '" ' . $selected . '>' . $anio . '</option>';
            }
            ?>
        </select>
    </div>


    <button class="btn-partes" type="submit">Enviar</button>
</form>
</div>

<!-- Script JavaScript para mostrar/ocultar el formulario popup y cambiar de pestañas -->
<script>
    function mostrarFormulario() {
        var formularioPopup = document.getElementById('formularioPopup');
        formularioPopup.style.display = 'block';
    }

    function cerrarFormulario() {
        var formularioPopup = document.getElementById('formularioPopup');
        formularioPopup.style.display = 'none';
    }

    function mostrarFormularioRegistro() {
        var formularioPopupRegistro = document.getElementById('formularioPopupRegistro');
        formularioPopupRegistro.style.display = 'block';
    }

    function cerrarFormularioRegistro() {
        var formularioPopupRegistro = document.getElementById('formularioPopupRegistro');
        formularioPopupRegistro.style.display = 'none';
    }

    function openTab(tabName) {
        // Oculta todos los contenidos de pestañas
        var tabContents = document.getElementsByClassName('tab-content');
        for (var i = 0; i < tabContents.length; i++) {
            tabContents[i].style.display = 'none';
        }

        // Muestra el contenido de la pestaña seleccionada
        document.getElementById(tabName).style.display = 'block';
    }

    function cerrarSesion() {
        alert('La sesión se ha cerrado correctamente');
        window.location.href = "index.php?cerrar_sesion=true";
    }
</script>

<script>
    // Definir variables globales para los campos de entrada
    var filtroNombreCompletoInput;
    var filtroTipoInput;
    var filtroFechaHoraInput;
    var filtroFechaHoraFinalInput;
    var filtroIncidenciaInput;

// Función para crear un objeto Date a partir de una cadena de fecha
function createDateFromFormat(dateString) {
    var parts = dateString.split(' ')[0].split('-');
    var year = parseInt(parts[0]);
    var month = parseInt(parts[1]) - 1; // Los meses en JavaScript van de 0 a 11
    var day = parseInt(parts[2]);

    // Crear el objeto Date con los componentes extraídos y establecer las horas, minutos y segundos en 00:00:00
    var date = new Date(year, month, day, 0, 0, 0);

    return date;
}


    function rellenarHoras(){
        // Obtener todas las filas de la tabla, excluyendo la primera (encabezado)
        var filas = document.querySelectorAll('.tablas-listado tr:not(#header-row)');
        
        // Iterar sobre las filas
        filas.forEach(function(fila) {
            // Obtener el tipo de la fila
            var tipo = fila.cells[2].textContent.trim();
            
            if (tipo.toLowerCase() === 'salida') {
                console.log("SALIDA");
                var idUser = fila.cells[1].getAttribute('value');
                var fechahorafila = fila.cells[3].textContent.trim();
                //console.log(fechahorafila);
                console.log(idUser);

            } else {
                console.log("NO");
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Llamar a la función rellenarHoras() cuando se cargue la página
        rellenarHoras();
    });


    // Función para aplicar los filtros
    function aplicarFiltros() {
        // Obtener los valores de cada campo de búsqueda
        var filtroNombreCompleto = filtroNombreCompletoInput.value.toLowerCase();
        var filtroTipo = filtroTipoInput.value.toLowerCase();
        var filtroFechaHora = filtroFechaHoraInput.value.toLowerCase();
        var filtroFechaHoraFinal = filtroFechaHoraFinalInput.value.toLowerCase();
        var filtroIncidencia = filtroIncidenciaInput.value.toLowerCase();

        // Obtener todas las filas de la tabla, excluyendo la primera (encabezado)
        var filas = document.querySelectorAll('.tablas-listado tr:not(#header-row)');

        // Iterar sobre las filas
        filas.forEach(function(fila) {
            var textoFila = fila.textContent.toLowerCase();
            var cumpleFiltros =
                textoFila.includes(filtroNombreCompleto) &&
                textoFila.includes(filtroTipo) &&
                textoFila.includes(filtroIncidencia);

            // Verificar si filtroFechaHoraFinal está lleno y la fila es menor que el rango
            if (filtroFechaHora && filtroFechaHoraFinal) {
                var filtroFechaHoraDate = createDateFromFormat(filtroFechaHora);
                var filtroFechaHoraFinalDate = createDateFromFormat(filtroFechaHoraFinal);

                // Obtener la fecha de la fila (suponiendo que esté en la cuarta celda)
                var filaFecha = fila.cells[3].textContent; // Suponiendo que la fecha está en la cuarta celda (índice 3) de la fila
                var filaFechaDate = createDateFromFormat(filaFecha);

                // Verificar si la fecha de la fila está dentro del rango
                if (!isNaN(filaFechaDate) && filtroFechaHoraDate <= filaFechaDate && filaFechaDate <= filtroFechaHoraFinalDate) {
                    console.log("Cumple filtros de fecha");
                } else {
                    console.log("No cumple filtros de fecha");
                    cumpleFiltros = false; // Si la fecha no cumple, entonces la fila no cumple con los filtros
                }
            }else if (filtroFechaHora) {
                cumpleFiltros = textoFila.includes(filtroFechaHora);
                
            }else if (filtroFechaHoraFinal){
                cumpleFiltros = textoFila.includes(filtroFechaHoraFinal);
            }


            // Establecer la visualización de la fila
            fila.style.display = cumpleFiltros ? '' : 'none';
        });
    }

    // Función para resetear los filtros
    function resetFiltros() {
        // Limpiar el valor de cada campo de entrada
        filtroNombreCompletoInput.value = '';
        filtroTipoInput.value = '';
        filtroFechaHoraInput.value = '';
        filtroFechaHoraFinalInput.value = '';
        filtroIncidenciaInput.value = '';

        // Restablecer el valor del campo de selección a su opción predeterminada
        var selectFiltroNombreCompleto = document.getElementById('filtroNombreCompleto');
        selectFiltroNombreCompleto.selectedIndex = 0;

        // Añadir un espacio al campo de tipo si está vacío
        if (filtroTipoInput.value.trim() === '') {
            filtroTipoInput.value = ' ';
        }

        // Aplicar los filtros después de resetear
        aplicarFiltros();
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Obtener las referencias a los campos de búsqueda
        filtroNombreCompletoInput = document.getElementById('filtroNombreCompleto');
        filtroTipoInput = document.getElementById('filtroTipo');
        filtroFechaHoraInput = document.getElementById('filtroFechaHora');
        filtroFechaHoraFinalInput = document.getElementById('filtroFechaHoraFinal');
        filtroIncidenciaInput = document.getElementById('filtroIncidencia');

        // Llamar a aplicarFiltros() para actualizar la lista al cargar la página
        aplicarFiltros();

        // Agregar un evento 'input' a cada campo de búsqueda
        var camposFiltro = document.querySelectorAll('.filtroCampo');
        camposFiltro.forEach(function(filtroInput) {
            filtroInput.addEventListener('input', function() {
                aplicarFiltros();
            });
        });
    });
</script>

<script>
    // Función para establecer una cookie
    function setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    // Función para obtener el valor de una cookie
    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    // Función para abrir la última pestaña guardada en la cookie
    function openLastTab() {
        var lastTab = getCookie("lastTab");
        if (lastTab) {
            openTab(lastTab);
        }
    }

    // Función para guardar la pestaña actual en la cookie
    function saveCurrentTab(tabName) {
        setCookie("lastTab", tabName, 7); // Guarda la última pestaña por 7 días
    }

    // Función para abrir una pestaña
    function openTab(tabName) {
        // Oculta todas las pestañas
        var tabs = document.getElementsByClassName("tab-content");
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].style.display = "none";
        }

        // Muestra la pestaña seleccionada
        document.getElementById(tabName).style.display = "block";

        // Guarda la pestaña actual en la cookie
        saveCurrentTab(tabName);
    }

    // Al cargar la página, abre la última pestaña guardada
    window.onload = function () {
        openLastTab();
    };


</script>


</body>
</html>
